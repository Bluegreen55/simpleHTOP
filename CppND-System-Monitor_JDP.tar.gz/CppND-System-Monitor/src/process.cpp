#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>

#include "process.h"

using std::string;
using std::to_string;
using std::vector;
using std::cout;

// TODO: Return this process's ID
int Process::Pid() { return pid_; }

// TODO: Return this process's CPU utilization
const float Process::CpuUtilization() { //return cpu_; }
 const string pidstr = std::to_string(pid_);
 string n0, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16, n17, n18, n19, n20, n21, n22; 
 string line, utime, stime, cutime, cstime, starttime; 
 float piduse, uptime, seconds;
 float Total = 0; 
 std::ifstream filestream(kProcDirectory + pidstr + kStatFilename);
 if (filestream.is_open()) {
     std::getline(filestream, line); 
     std::istringstream linestream(line);
     linestream >> n0 >> n1 >> n2 >> n3 >> n4 >> n5 >> n6 >> n7 >> n8 >> n9 >> n10 >> n11 >> n12 >> n13 >> n14 >> n15 >> n16 >> n17 >> n18 >> n19 >> n20 >> n21 >> n22;   
     utime = n13;
     stime = n14;
     cutime = n15;
     cstime = n16;
     starttime = n21;
     //std::cout<<n0<<" "<<utime<<" "<<stime<<" "<<cutime<<" "<<cstime<<" "<<starttime<<std::endl;
     Total = stof(utime) + stof(stime) + stof(cutime) + stof(cstime);
     uptime = LinuxParser::UpTime(); //in seconds
     seconds = uptime - (stof(starttime)/sysconf(_SC_CLK_TCK));
     piduse = (Total/sysconf(_SC_CLK_TCK)/seconds);
     // std::cout<<Total<<" "<<uptime<<" "<<seconds<<" "<<piduse<<std::endl;
    }
return piduse; 
}

// TODO: Return the command that generated this process
string Process::Command() { return cmd_; }

// TODO: Return this process's memory utilization
string Process::Ram() { return ram_; }

// TODO: Return the user (name) that generated this process
string Process::User() { return user_; }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { return upT_; }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a) const 
{ return (a.cpu_ < this->cpu_); }