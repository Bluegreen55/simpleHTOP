#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <iostream>

#include "format.h"
#include "linux_parser.h"
#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, version, kernel;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { string line, units;
  string key;
  float act_val, tot_val, value;
  std::ifstream filestream(kProcDirectory + kMeminfoFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value >> units) {
        if (key == "Active:") {
          act_val = value;}
          //return act_val;}
        if (key == "MemTotal:"){
          tot_val = value;}
          //return tot_val;}
      }
    }
  }
  value = act_val/tot_val;
  return value; }

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 
  string line, idle, uptime;
  long seconds = 0;
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  if (stream.is_open()) { 
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> uptime >> idle;
    seconds = stol(uptime); 
    //std::cout<<seconds<<std::endl; 
    return seconds;  
  }
  return seconds; 
}

// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { return 0; }

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid[[maybe_unused]]) { return 0; }

// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() { return 0; }

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() { return 0; }

// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() {  
 string line, kUser, kNice, kSystem, kIdle, kIOwait, kIRQ, kSoftIRQ, kSteal, kGuest, kGuestNice; 
 string key; 
 vector<string> sysuse;
 std::ifstream filestream(kProcDirectory + kStatFilename);
 if (filestream.is_open()) {
     std::getline(filestream, line); 
     std::istringstream linestream(line);
     while (linestream >> key >> kUser >>kNice >> kSystem >>kIdle >>kIOwait >>kIRQ >>kSoftIRQ>>kSteal>>kGuest>>kGuestNice) 
     {
       if (key == "cpu") {
         sysuse.push_back(kUser); 
         sysuse.push_back(kNice);
         sysuse.push_back(kSystem); 
         sysuse.push_back(kIdle); 
         sysuse.push_back(kIOwait); 
         sysuse.push_back(kIRQ); 
         sysuse.push_back(kSoftIRQ); 
         sysuse.push_back(kSteal);
         sysuse.push_back(kGuest);
         sysuse.push_back(kGuestNice); 
         return sysuse;
       } 
    }
  }
return sysuse; }

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() {   string line;
  string key;
  int value;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "processes") {
          return value;
        }
      }
    }
  }
  return value; }

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() { string line;
  string key;
  int value;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "procs_running") {
          //std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value; }

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) {  //return string(); }
  string line;
  string key;
  string value;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), '=', ' ');
      std::istringstream linestream(line);
      linestream >> value;
    }
  }
  return value; } 
// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) { //return string(); }
  string line, units;
  string key;
  string RAMvalue, MBram_str;
  int MBram;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      while (linestream >> key >> RAMvalue >> units) {
        if (key == "VmSize:") {
          MBram = stoi(RAMvalue) / 1024;
          MBram_str = to_string(MBram);
          return MBram_str;}
      }
    }
  }
  return MBram_str; }

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) { //return string(); }
  string line;
  string key;
  string value;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatusFilename);
  //std::cout<<kProcDirectory + to_string(pid) + kStatusFilename << std::endl;
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      //std::cout<<line<<std::endl;
      while (linestream >> key >> value) {
        if (key == "Uid:") {
          //std::cout<<value<<std::endl;
          return value;
        }
      }
    }
  }
  return value; }
// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) { //return string(); }
  string line, username, value, x ;
  string uid = Uid(pid);
  std::ifstream filestream(kPasswordPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ':',' ');
      std::istringstream linestream(line);
      while (linestream >> username >> x >> value) {
        if (value == uid) {
          return username;
        }
      }
    }
  }
  return username; }

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) { 
  string uptime, idle, line, upT_sys;
  int ind = 22;  //location in the line of data
  long seconds = 0;
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    for( int i = 0; i<ind; i++){
      linestream >> uptime;
    }
    //std::cout<<uptime<<std::endl; 
    seconds = stol(uptime)/sysconf(_SC_CLK_TCK);
    return seconds;  
  }
  return seconds; 
}

