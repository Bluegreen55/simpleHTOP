#include "processor.h"
#include "linux_parser.h"
#include <string>
#include <vector>
#include <iostream>

using std::string;
using std::vector;
using std::stof;

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { //return 0.0; }
    vector<string> cpu_usage = LinuxParser::CpuUtilization();
    float Idle, NonIdle, Total; // totald, idled;
    Idle = stof(cpu_usage[3]) + stof(cpu_usage[4]);
    NonIdle = stof(cpu_usage[0]) + stof(cpu_usage[1]) + stof(cpu_usage[5]) +stof(cpu_usage[6]) +stof(cpu_usage[7]);
    Total = Idle + NonIdle;
    // //totald = 
    // //idled = 
    return ((Total - Idle)/Total);
    }