#include <string>
#include <iostream>

#include "format.h"

using std::string;


// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) { 
    long int HH, MM, SS;
    string output;
    HH = seconds / 3600;
    MM = (seconds%3600) /60; 
    SS =  (seconds%3600) % 60; 
    output = std::to_string(HH)+":"+std::to_string(MM)+ std::to_string(SS);
    return output; }