#ifndef PROCESS_H
#define PROCESS_H

#include <string>
#include "linux_parser.h"

using namespace LinuxParser;
/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
  public:
    Process(int pid) { 
      pid_ = pid;
      user_ = LinuxParser::User(pid_);
      cmd_ = LinuxParser::Command(pid_);
      ram_ = LinuxParser::Ram(pid_);
      upT_ = LinuxParser::UpTime(pid_);
      cpu_ = Process::CpuUtilization();
      };
  int Pid();                               // TODO: See src/process.cpp
  std::string User();                      // TODO: See src/process.cpp
  std::string Command();                   // TODO: See src/process.cpp
  const float CpuUtilization();                  // TODO: See src/process.cpp
  std::string Ram();                       // TODO: See src/process.cpp
  long int UpTime();                       // TODO: See src/process.cpp
  bool operator<(Process const& a) const;  // TODO: See src/process.cpp

  // TODO: Declare any necessary private members
 private:
    int pid_;
    std::string user_, cmd_, ram_;
    long int upT_;
    float cpu_;
};

#endif